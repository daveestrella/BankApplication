package com.devsu.hackerearth.backend.client.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {

		List<ClientDto> response = new ArrayList<>();

		try {

			var allClients = clientRepository.findAll();

			for (Client client : allClients) {
				ClientDto clientDto = mapClientToDTO(client);

				response.add(clientDto);
			}

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

		return response;
	}

	@Override
	public ClientDto getById(Long id) {

		ClientDto response = null;

		try {

			var client = clientRepository.findById(id);

			if (client != null)
				response = mapClientToDTO(client.get());

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

		return response;
	}

	@Override
	public ClientDto create(ClientDto clientDto) {

		ClientDto response = null;

		try {
			Client client = new Client();
			client.setName(clientDto.getName());
			client.setDni(clientDto.getDni());
			client.setGender(clientDto.getGender());
			client.setAge(clientDto.getAge());
			client.setAddress(clientDto.getAddress());
			client.setPhone(clientDto.getPhone());
			client.setPassword(clientDto.getPassword());
			client.setActive(clientDto.isActive());

			client = clientRepository.save(client);

			response = mapClientToDTO(client);

		} catch (

		Exception ex) {
			System.out.println(ex.getMessage());
		}

		return response;
	}

	@Override
	public ClientDto update(ClientDto clientDto) {

		ClientDto response = null;

		try {

			var tempClient = clientRepository.findById(clientDto.getId());

			if (tempClient != null) {
				var client = tempClient.get();
				client.setName(clientDto.getName());
				client.setDni(clientDto.getDni());
				client.setGender(clientDto.getGender());
				client.setAge(clientDto.getAge());
				client.setAddress(clientDto.getAddress());
				client.setPhone(clientDto.getPhone());
				client.setPassword(clientDto.getPassword());
				client.setActive(clientDto.isActive());

				client = clientRepository.save(client);

				response = mapClientToDTO(client);
			}

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

		return response;
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {

		ClientDto response = null;

		try {

			var tempClient = clientRepository.findById(id);

			if (tempClient != null) {
				var client = tempClient.get();
				client.setActive(partialClientDto.isActive());

				client = clientRepository.save(client);

				response = mapClientToDTO(client);
			}

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}

		return response;
	}

	@Override
	public void deleteById(Long id) {

		try {

			var client = clientRepository.findById(id);

			if (client != null)
				clientRepository.delete(client.get());
			else
				throw new RuntimeException("No se encuentra el cliente");

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	private ClientDto mapClientToDTO(Client client) {
		ClientDto clientDto = new ClientDto();

		clientDto.setId(client.getId());
		clientDto.setDni(client.getDni());
		clientDto.setName(client.getName());
		clientDto.setPassword(client.getPassword());
		clientDto.setGender(client.getGender());
		clientDto.setAge(client.getAge());
		clientDto.setAddress(client.getAddress());
		clientDto.setPhone(client.getPhone());
		clientDto.setActive(client.isActive());

		return clientDto;
	}
}
