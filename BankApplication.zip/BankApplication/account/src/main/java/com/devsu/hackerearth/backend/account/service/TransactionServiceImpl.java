package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;
    private final RestTemplate restTemplate;

    public TransactionServiceImpl(
            TransactionRepository transactionRepository,
            AccountRepository accountRepository,
            RestTemplateBuilder restBuilder) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
        this.restTemplate = restBuilder.build();
    }

    @Override
    public List<TransactionDto> getAll() {

        List<TransactionDto> response = new ArrayList<>();

        try {

            var allTransactions = transactionRepository.findAll();

            for (Transaction transaction : allTransactions) {
                TransactionDto transactionDto = mapTransactionToDTO(transaction);

                response.add(transactionDto);
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    @Override
    public TransactionDto getById(Long id) {

        TransactionDto response = new TransactionDto();

        try {

            var transaction = transactionRepository.findById(id);

            if (transaction != null)
                response = mapTransactionToDTO(transaction.get());

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    @Transactional
    @Override
    public TransactionDto create(TransactionDto transactionDto) {

        TransactionDto response = new TransactionDto();

        try {

            Account account = accountRepository.findById(transactionDto.getAccountId())
                    .orElseThrow(() -> new RuntimeException("Cuenta no existe"));

            double newBalance = account.getInitialAmount() + transactionDto.getAmount();

            if (newBalance < 0)
                throw new RuntimeException("Saldo no disponible");

            account.setInitialAmount(newBalance);
            accountRepository.save(account);

            Transaction transaction = new Transaction();
            transaction.setDate(new Date());
            transaction.setType(transactionDto.getType());
            transaction.setAmount(transactionDto.getAmount());
            transaction.setBalance(newBalance);
            transaction.setAccountId(transactionDto.getAccountId());

            transaction = transactionRepository.save(transaction);

            response = mapTransactionToDTO(transaction);

        } catch (

        Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {

        List<BankStatementDto> response = new ArrayList<>();

        try {

            ClientDto clientDto = getClientById(clientId);

            if (clientDto == null)
                throw new RuntimeException("No se encuentra el cliente");

            List<Account> accountList = accountRepository.findByClientId(clientId);

            if (accountList == null)
                throw new RuntimeException("No existen cuentas asociadas al cliente");

            for (Account account : accountList) {

                List<Transaction> transactionList = transactionRepository.findByAccountIdAndDateBetweenOrderByDate(
                        account.getId(),
                        dateTransactionStart, dateTransactionEnd);
                System.out.println("Transacciones: " + transactionList.size());

                for (Transaction transaction : transactionList) {

                    BankStatementDto bankStatementDto = new BankStatementDto();

                    bankStatementDto.setClient(clientDto.getName());
                    bankStatementDto.setAccountNumber(account.getNumber());
                    bankStatementDto.setAccountType(account.getType());
                    bankStatementDto.setInitialAmount(transaction.getBalance() - transaction.getAmount());
                    bankStatementDto.setActive(account.isActive());
                    bankStatementDto.setDate(transaction.getDate());
                    bankStatementDto.setTransactionType(transaction.getType());
                    bankStatementDto.setAmount(transaction.getAmount());
                    bankStatementDto.setBalance(transaction.getBalance());

                    response.add(bankStatementDto);
                }
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {

        TransactionDto response = new TransactionDto();

        try {

            Transaction transaction = transactionRepository.findFirstByAccountIdOrderByDateDesc(accountId);

            if (transaction != null)
                response = mapTransactionToDTO(transaction);

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    private ClientDto getClientById(Long clientId) {

        ClientDto response = null;

        try {
            String url = "http://localhost:8001/api/clients/" + clientId;

            ResponseEntity<ClientDto> resp = restTemplate.getForEntity(url, ClientDto.class);

            response = resp.getBody();

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    private TransactionDto mapTransactionToDTO(Transaction transaction) {
        TransactionDto transactionDto = new TransactionDto();

        transactionDto.setId(transaction.getId());
        transactionDto.setDate(transaction.getDate());
        transactionDto.setType(transaction.getType());
        transactionDto.setAmount(transaction.getAmount());
        transactionDto.setBalance(transaction.getBalance());
        transactionDto.setAccountId(transaction.getAccountId());

        return transactionDto;
    }
}
