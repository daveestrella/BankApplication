package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    @Override
    public List<AccountDto> getAll() {

        List<AccountDto> response = new ArrayList<>();

        try {

            var allAccounts = accountRepository.findAll();

            for (Account account : allAccounts) {
                AccountDto accountDto = mapAccountToDTO(account);

                response.add(accountDto);
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    @Override
    public AccountDto getById(Long id) {

        AccountDto response = new AccountDto();

        try {

            var account = accountRepository.findById(id);

            if (account != null)
                response = mapAccountToDTO(account.get());

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    @Override
    public AccountDto create(AccountDto accountDto) {

        AccountDto response = new AccountDto();

        try {
            Account account = new Account();
            account.setInitialAmount(accountDto.getInitialAmount());
            account.setNumber(accountDto.getNumber());
            account.setType(accountDto.getType());
            account.setActive(accountDto.isActive());
            account.setClientId(accountDto.getClientId());

            account = accountRepository.save(account);

            response = mapAccountToDTO(account);

        } catch (

        Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    @Override
    public AccountDto update(Long id, AccountDto accountDto) {

        AccountDto response = new AccountDto();

        try {

            var tempAccount = accountRepository.findById(id);

            if (tempAccount != null) {
                var account = tempAccount.get();
                account.setInitialAmount(accountDto.getInitialAmount());
                account.setNumber(accountDto.getNumber());
                account.setType(accountDto.getType());
                account.setActive(accountDto.isActive());

                account = accountRepository.save(account);

                response = mapAccountToDTO(account);
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {

        AccountDto response = new AccountDto();

        try {

            var tempAccount = accountRepository.findById(id);

            if (tempAccount != null) {
                var account = tempAccount.get();
                account.setActive(partialAccountDto.isActive());

                account = accountRepository.save(account);

                response = mapAccountToDTO(account);
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return response;
    }

    @Override
    public void deleteById(Long id) {

        try {

            var account = accountRepository.findById(id);

            if (account != null)
                accountRepository.delete(account.get());

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    private AccountDto mapAccountToDTO(Account account) {
        AccountDto accountDTO = new AccountDto();

        accountDTO.setId(account.getId());
        accountDTO.setNumber(account.getNumber());
        accountDTO.setActive(account.isActive());
        accountDTO.setInitialAmount(account.getInitialAmount());
        accountDTO.setType(account.getType());
        accountDTO.setClientId(account.getClientId());

        return accountDTO;
    }
}
