package com.devsu.hackerearth.backend.account;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientDto;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class sampleTest {

	@Autowired
	private TestRestTemplate restTemplate;

	private static final String CLIENT_SERVICE_URL = "http://localhost:8001/api/clients";

	@Test
	void integrationTest() {
		ClientDto clientDto = new ClientDto();
		clientDto.setDni("12345678");
		clientDto.setName("Juan Pérez");
		clientDto.setPassword("secreto123");
		clientDto.setGender("M");
		clientDto.setAge(30);
		clientDto.setAddress("Av. Siempre Viva 123");
		clientDto.setPhone("0999999999");
		clientDto.setActive(true);

		ResponseEntity<ClientDto> clientResponse = restTemplate.postForEntity(CLIENT_SERVICE_URL, clientDto,
				ClientDto.class);
		assertEquals(HttpStatus.CREATED, clientResponse.getStatusCode());
		Long clientId = clientResponse.getBody().getId();

		AccountDto newAccount = new AccountDto(1L, "1234567", "Ahorro", 5000.0, true, clientId);

		ResponseEntity<AccountDto> accountResponse = restTemplate.postForEntity("/api/accounts", newAccount,
				AccountDto.class);

		assertEquals(HttpStatus.CREATED, accountResponse.getStatusCode());
		assertEquals("1234567", accountResponse.getBody().getNumber());
		assertEquals(clientId, accountResponse.getBody().getClientId());
	}
}
